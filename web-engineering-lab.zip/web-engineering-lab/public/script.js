// script.js – classic script carried over from Labs 1 and 2
console.log("script.js loaded");
