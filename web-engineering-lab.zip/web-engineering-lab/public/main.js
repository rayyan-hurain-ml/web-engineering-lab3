// main.js
import { delay, makeCounter } from "./utils.js";

const status = document.querySelector("#status");
const tbody = document.querySelector("#schedule tbody");
const total = tbody.querySelectorAll("tr").length;
const nextBooking = makeCounter();

// One delegated listener on <tbody> handles every "Select" button,
// including rows that might be added later.
tbody.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-day]");
  if (!button) return;

  const day = button.dataset.day;
  const row = button.closest("tr");

  status.textContent = `Updating ${day}…`;
  await delay(1000); // pauses only this handler – the page stays responsive

  const selected = row.classList.toggle("selected");
  const count = document.querySelectorAll("#schedule tr.selected").length;

  status.textContent = selected
    ? `Booking #${nextBooking()} confirmed for ${day}. ${count} of ${total} slots booked.`
    : `Booking for ${day} cancelled. ${count} of ${total} slots booked.`;
});
