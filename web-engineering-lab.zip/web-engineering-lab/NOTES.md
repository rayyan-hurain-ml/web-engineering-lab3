# Lab 04 – Notes (Rayyan Hurain, Roll No. 0108)

## Part A – Specificity (Task 2)

| Selector | Specificity (ids, classes/attrs, elements) | Colour |
|---|---|---|
| `nav ul li a` | (0,0,4) | purple |
| `.nav-link` | (0,1,0) | darkgreen |
| `a[aria-current="location"]` | (0,1,1) | crimson |
| `:where(nav ul li) a` | (0,0,1) | purple |

Specificity is compared left to right, never added, so one class (0,1,0) beats four
elements (0,0,4).

* **Send Feedback** link: matches `nav ul li a` and `.nav-link` -> `.nav-link` wins -> **darkgreen**.
* **Office Hours** link (`aria-current`): matches all three -> (0,1,1) wins -> **crimson**.
* Measured in Chrome: `rgb(0, 100, 0)` and `rgb(220, 20, 60)`.
* Adding `!important` to `.nav-link` turned both links green (`rgb(0, 100, 0)`) – a trap,
  because it jumps over the more specific `a[aria-current]` rule.
* Real fix: lower the over-specific selector with `:where(nav ul li) a { ... }` (0,0,1).

## Part C – Event loop (Task 11)

```js
console.log("1 start");
setTimeout(() => console.log("2 timeout"), 0);
Promise.resolve().then(() => console.log("3 promise"));
console.log("4 end");
```

**Prediction:** `1 start`, `4 end`, `3 promise`, `2 timeout`

**Result in the Console:** `1 start`, `4 end`, `3 promise`, `2 timeout` (matches).

**Why:**
1. `console.log("1 start")` runs on the call stack immediately.
2. `setTimeout` hands the callback to the browser; it goes to the *task queue* after 0 ms.
3. `Promise.resolve().then(...)` puts its callback in the *microtask queue*.
4. `console.log("4 end")` runs – the synchronous code is now finished and the stack is empty.
5. The event loop empties the microtask queue first -> `3 promise`.
6. Only then does it take the next task -> `2 timeout`.

**Closure:** `makeCounter()` returns an inner function that keeps using `count` after
`makeCounter` has returned, so every call to `nextBooking()` gives 1, 2, 3, ...

**async/await:** `await delay(1000)` pauses only that click handler; the call stack is free,
so the page stays responsive during the one-second wait.
